"""
For Finding The Total
Author Divya Prabhakar
"""

def requisition_total():
    amount = 0.0
    while True:
        item_input = input("Enter the items from the staff ")
        product_price = float(input("Enter the price of the product "))
        amount  += product_price
        print(f" $ {amount:.2f}")
        
    
      
def main():
        requisition_total()
main()
              

        


