"""
For Printing Staff Information
Author Divya Prabhakar
"""
def staff_info():              #function call 
    id_counter = 10000
    return id_counter+1        #calculating the id counter 

#prompt input
date  = input("Enter the Date:")
staff_ID = input("Enter the Staff ID: ")
staff_name = input("Enter the Staff Name:")
requisition_id = input("Enter the requisition ID")
    
    
id_counter = 10000
requisition_id = staff_info()

#printing the desired output 
print("Printing Staff Information")
print(f"Date: {date}")
print(f"Staff ID: {staff_ID}")
print(f"Staff Name:{staff_name}")
print(f"Requisition ID: {requisition_id}")



