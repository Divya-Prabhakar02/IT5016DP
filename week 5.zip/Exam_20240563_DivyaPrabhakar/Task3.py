"""
For approving the decisions based on conditions provided
Author Divya Prabhakar 
"""
def staff_info():              #function call 
    id_counter = 10000
    return id_counter+1        #calculating the id counter 

#prompt input
date  = input("Enter the Date:")
staff_ID = input("Enter the Staff ID: ")
staff_name = input("Enter the Staff Name:")
requisition_id = input("Enter the requisition ID")
    
    
id_counter = 10000
requisition_id = staff_info()

#printing the desired output 
print("Printing Staff Information")
print(f"Date: {date}")
print(f"Staff ID: {staff_ID}")
print(f"Staff Name:{staff_name}")
print(f"Requisition ID: {requisition_id}")

def requisition_total(): #calling the main function 
    amount = 0.0 #accepting the amount initially
    staff_info(staff_name)
    print(staff_info(staff_name))
    while True:
        item_input = input("Enter the items from the staff ")#accepting the item name from the staff 
        product_price = float(input("Enter the price of the product "))#accepting the item price 
        amount  += product_price #calculating total of the item price 
        print(f" $ {amount:.2f}") #printing the final amount 
        return amount 

def requisition_approval(amount):
    
    if amount < 500:#Applying condition
        print("Status :Approved")# Printing response according to Request
        print(f"Approval Reference Number:{staff_info(staff_ID, staff_ID[-1:-4])}")
    else:
        print("Status:Pending")

def main():
    requisition_approval()
main()





        